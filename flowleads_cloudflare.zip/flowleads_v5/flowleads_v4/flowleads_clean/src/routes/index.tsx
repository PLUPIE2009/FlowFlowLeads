import { createFileRoute } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { Check, Target, Mail, TrendingUp, Menu, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "FlowLeads. Meer klanten, meer groei" },
      { name: "description", content: "B2B leadgeneratie op maat. Wij bouwen je leadlijsten, schrijven de outreach en leveren warme contacten. Jij sluit de deals." },
      { property: "og:title", content: "FlowLeads. Meer klanten, meer groei" },
      { property: "og:description", content: "Een constante stroom van gekwalificeerde leads voor jouw bedrijf." },
    ],
  }),
  component: Index,
});

const Logo = ({ height = 48 }: { height?: number }) => (
  <img
    src="/logo.png"
    alt="FlowLeads"
    height={height}
    style={{ display: "block", objectFit: "contain" }}
  />
);

function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll<HTMLElement>(".reveal, .reveal-title, .reveal-left, .step-line");
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const el = entry.target as HTMLElement;
            const delay = el.dataset.delay ? parseInt(el.dataset.delay) : 0;
            setTimeout(() => el.classList.add("is-visible"), delay);
            io.unobserve(el);
          }
        });
      },
      { threshold: 0.15, rootMargin: "0px 0px -50px 0px" }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
}

const TIME_SLOTS = ["09:00","09:30","10:00","10:30","11:00","11:30","13:00","13:30","14:00","14:30","15:00","15:30","16:00"];

const inputStyle: React.CSSProperties = {
  width: "100%",
  height: 44,
  padding: "0 14px",
  fontFamily: "Inter, system-ui, sans-serif",
  fontSize: 15,
  color: "#061e3e",
  background: "#fff",
  border: "1px solid rgba(6,30,62,0.15)",
  borderRadius: 6,
  outline: "none",
  transition: "border-color 150ms, box-shadow 150ms",
};

const labelStyle: React.CSSProperties = {
  display: "block",
  fontFamily: "Inter, system-ui, sans-serif",
  fontWeight: 500,
  fontSize: 14,
  color: "#061e3e",
  marginBottom: 6,
  textAlign: "left",
};

function BookingForm() {
  const [form, setForm] = useState({ name: "", email: "", phone: "", preferred_date: "", preferred_time: "" });
  const [countryCode, setCountryCode] = useState("+32");
  const [phoneFocused, setPhoneFocused] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);

  const update = (k: string, v: string) => setForm((f) => ({ ...f, [k]: v }));

  const onFocus = (e: React.FocusEvent<HTMLInputElement | HTMLSelectElement>) => {
    e.currentTarget.style.borderColor = "#135aaa";
    e.currentTarget.style.boxShadow = "0 0 0 3px rgba(19,90,170,0.15)";
  };
  const onBlur = (e: React.FocusEvent<HTMLInputElement | HTMLSelectElement>) => {
    e.currentTarget.style.borderColor = "rgba(6,30,62,0.15)";
    e.currentTarget.style.boxShadow = "none";
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (!form.name.trim()) errs.name = "Vul je naam in.";
    if (!form.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) errs.email = "Vul een geldig e-mailadres in.";
    if (!form.phone.trim()) errs.phone = "Vul je telefoonnummer in.";
    if (!form.preferred_date) errs.preferred_date = "Kies een datum.";
    if (!form.preferred_time) errs.preferred_time = "Kies een tijdstip.";
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;

    setSubmitting(true);
    setServerError(null);
    const fullPhone = `${countryCode} ${form.phone.trim()}`;
    const { error } = await supabase.from("bookings").insert({
      name: form.name.trim(),
      email: form.email.trim(),
      phone: fullPhone,
      preferred_date: form.preferred_date,
      preferred_time: form.preferred_time,
    });
    setSubmitting(false);
    if (error) {
      setServerError("Er ging iets mis. Probeer het opnieuw.");
      return;
    }
    // Fire-and-forget Formspree notification
    fetch("https://formspree.io/f/mzdqzada", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({
        naam: form.name.trim(),
        email: form.email.trim(),
        telefoonnummer: fullPhone,
        datum: form.preferred_date,
        tijdstip: form.preferred_time,
      }),
    }).catch(() => {});
    setDone(true);
  };

  const cardStyle: React.CSSProperties = {
    background: "#fff",
    boxShadow: "0 4px 24px rgba(6,30,62,0.08)",
    borderRadius: 12,
    padding: 40,
    color: "#061e3e",
    textAlign: "left",
  };

  if (done) {
    return (
      <div style={cardStyle}>
        <h3 className="font-display" style={{ fontWeight: 700, fontSize: 24, color: "#061e3e", marginBottom: 10 }}>
          Bedankt!
        </h3>
        <p style={{ fontFamily: "Inter, system-ui, sans-serif", fontSize: 15, color: "#4a5568", lineHeight: 1.7 }}>
          We nemen zo snel mogelijk contact met je op ter bevestiging.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={submit} style={cardStyle} noValidate>
      <div style={{ display: "grid", gap: 18 }}>
        <div>
          <label style={labelStyle} htmlFor="b-name">Volledige naam</label>
          <input id="b-name" type="text" value={form.name} onChange={(e) => update("name", e.target.value)} onFocus={onFocus} onBlur={onBlur} style={inputStyle} />
          {errors.name && <p style={{ color: "#c53030", fontSize: 13, marginTop: 6 }}>{errors.name}</p>}
        </div>
        <div>
          <label style={labelStyle} htmlFor="b-email">E-mailadres</label>
          <input id="b-email" type="email" value={form.email} onChange={(e) => update("email", e.target.value)} onFocus={onFocus} onBlur={onBlur} style={inputStyle} />
          {errors.email && <p style={{ color: "#c53030", fontSize: 13, marginTop: 6 }}>{errors.email}</p>}
        </div>
        <div>
          <label style={labelStyle} htmlFor="b-phone">Telefoonnummer</label>
          <div
            style={{
              display: "flex",
              alignItems: "stretch",
              height: 44,
              background: "#fff",
              border: `1px solid ${phoneFocused ? "#135aaa" : "rgba(6,30,62,0.15)"}`,
              borderRadius: 6,
              boxShadow: phoneFocused ? "0 0 0 3px rgba(19,90,170,0.15)" : "none",
              transition: "border-color 150ms, box-shadow 150ms",
              overflow: "hidden",
            }}
          >
            <select
              value={countryCode}
              onChange={(e) => setCountryCode(e.target.value)}
              onFocus={() => setPhoneFocused(true)}
              onBlur={() => setPhoneFocused(false)}
              aria-label="Landcode"
              style={{
                height: "100%",
                padding: "0 10px",
                fontFamily: "Inter, system-ui, sans-serif",
                fontSize: 15,
                color: "#061e3e",
                background: "#fff",
                border: "none",
                borderRight: "1px solid rgba(6,30,62,0.12)",
                outline: "none",
                cursor: "pointer",
              }}
            >
              <option value="+32">🇧🇪 +32</option>
              <option value="+31">🇳🇱 +31</option>
            </select>
            <input
              id="b-phone"
              type="tel"
              value={form.phone}
              onChange={(e) => update("phone", e.target.value)}
              onFocus={() => setPhoneFocused(true)}
              onBlur={() => setPhoneFocused(false)}
              style={{
                flex: 1,
                height: "100%",
                padding: "0 14px",
                fontFamily: "Inter, system-ui, sans-serif",
                fontSize: 15,
                color: "#061e3e",
                background: "#fff",
                border: "none",
                outline: "none",
              }}
            />
          </div>
          {errors.phone && <p style={{ color: "#c53030", fontSize: 13, marginTop: 6 }}>{errors.phone}</p>}
        </div>
        <div style={{ display: "grid", gap: 18, gridTemplateColumns: "1fr 1fr" }}>
          <div>
            <label style={labelStyle} htmlFor="b-date">Gewenste datum</label>
            <input id="b-date" type="date" value={form.preferred_date} onChange={(e) => update("preferred_date", e.target.value)} onFocus={onFocus} onBlur={onBlur} style={inputStyle} />
            {errors.preferred_date && <p style={{ color: "#c53030", fontSize: 13, marginTop: 6 }}>{errors.preferred_date}</p>}
          </div>
          <div>
            <label style={labelStyle} htmlFor="b-time">Gewenst tijdstip</label>
            <select id="b-time" value={form.preferred_time} onChange={(e) => update("preferred_time", e.target.value)} onFocus={onFocus} onBlur={onBlur} style={inputStyle}>
              <option value="">Kies een tijdstip</option>
              {TIME_SLOTS.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
            {errors.preferred_time && <p style={{ color: "#c53030", fontSize: 13, marginTop: 6 }}>{errors.preferred_time}</p>}
          </div>
        </div>
        {serverError && <p style={{ color: "#c53030", fontSize: 14 }}>{serverError}</p>}
        <button type="submit" disabled={submitting} className="btn btn-primary" style={{ marginTop: 6 }}>
          {submitting ? "Bezig met inplannen..." : "Gesprek inplannen"}
        </button>
      </div>
    </form>
  );
}

function Index() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useReveal();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const navLinks = [
    { href: "#wat-wij-doen", label: "Over ons" },
    { href: "#diensten", label: "Diensten" },
    { href: "#hoe-het-werkt", label: "Hoe het werkt" },
    { href: "#prijzen", label: "Prijzen" },
    { href: "#contact", label: "Contact" },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* NAVBAR */}
      <header className={`nav-shell ${scrolled ? "scrolled" : ""}`}>
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <a href="#" aria-label="FlowLeads home" className="flex items-center">
            <Logo height={44} />
          </a>
          <nav className="hidden md:flex items-center gap-9">
            {navLinks.map((l) => (
              <a key={l.href} href={l.href} className="nav-link">{l.label}</a>
            ))}
          </nav>
          <a href="#contact" className="hidden md:inline-flex btn btn-primary" style={{ padding: "10px 22px", fontSize: 13 }}>
            Gratis gesprek
          </a>
          <button
            className="md:hidden p-2 cursor-pointer"
            onClick={() => setOpen(!open)}
            aria-label="Toggle menu"
          >
            {open ? <X size={24} color="#061e3e" /> : <Menu size={24} color="#061e3e" />}
          </button>
        </div>
        {open && (
          <div className="md:hidden bg-white px-6 pb-5 pt-2 flex flex-col gap-5" style={{ borderTop: "1px solid rgba(6,30,62,0.08)" }}>
            {navLinks.map((l) => (
              <a key={l.href} href={l.href} onClick={() => setOpen(false)} className="nav-link">{l.label}</a>
            ))}
            <a href="#contact" onClick={() => setOpen(false)} className="btn btn-primary self-start" style={{ padding: "10px 22px", fontSize: 13 }}>
              Gratis gesprek
            </a>
          </div>
        )}
      </header>

      {/* HERO */}
      <section
        id="over-ons"
        className="relative flex items-center justify-center px-6 text-center overflow-hidden"
        style={{
          minHeight: "calc(100vh - 64px)",
          background: "radial-gradient(ellipse at 60% 40%, rgba(19,90,170,0.07) 0%, transparent 70%), #ffffff",
        }}
      >
        <div
          aria-hidden
          className="pointer-events-none absolute"
          style={{
            width: 600, height: 600,
            top: "-15%", left: "-10%",
            background: "#135aaa",
            opacity: 0.04,
            borderRadius: "50%",
            filter: "blur(80px)",
          }}
        />
        <div
          aria-hidden
          className="pointer-events-none absolute"
          style={{
            width: 600, height: 600,
            bottom: "-20%", right: "-10%",
            background: "#135aaa",
            opacity: 0.04,
            borderRadius: "50%",
            filter: "blur(80px)",
          }}
        />


        <div className="relative max-w-4xl mx-auto py-20 z-10">
          <h1
            className="font-display hero-anim hero-d-0 mx-auto"
            style={{
              fontWeight: 700,
              fontSize: "clamp(38px, 7vw, 64px)",
              lineHeight: 1.15,
              letterSpacing: "-0.5px",
              color: "#061e3e",
              maxWidth: 820,
            }}
          >
            Een constante stroom van gekwalificeerde leads voor jouw bedrijf.
          </h1>
          <p
            className="hero-anim hero-d-1 mx-auto mt-7"
            style={{ fontWeight: 400, fontSize: 17, color: "#4a5568", maxWidth: 600, lineHeight: 1.75 }}
          >
            Wij bouwen je leadlijsten, schrijven de outreach en leveren warme contacten aan. Jij sluit de deals.
          </p>
          <div className="hero-anim hero-d-2 mt-10 flex flex-wrap gap-4 justify-center">
            <a href="#diensten" className="btn btn-primary">Ontdek meer</a>
            <a href="#contact" className="btn btn-outline">Neem contact op</a>
          </div>
          <div className="hero-anim hero-d-3 mt-10 flex flex-wrap items-center justify-center gap-3">
            {["Geen lang contract", "Resultaat binnen 30 dagen", "100% op maat"].map((t) => (
              <span key={t} className="trust-pill">
                <Check size={14} color="#135aaa" strokeWidth={3} />
                {t}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* DIENSTEN */}
      <section id="diensten" className="px-6 py-28" style={{ background: "#f4f7fc" }}>
        <div id="wat-wij-doen" className="max-w-6xl mx-auto text-center">
          <h2 className="font-display reveal-title" style={{ fontWeight: 700, fontSize: "clamp(32px, 5vw, 44px)", color: "#061e3e", lineHeight: 1.2 }}>
            Wat wij doen
          </h2>
          <p className="reveal mt-4" data-delay="100" style={{ fontSize: 16, color: "#4a5568", lineHeight: 1.75 }}>
            Alles wat nodig is om jouw klantenbestand te laten groeien.
          </p>

          <div className="mt-16 grid gap-8 md:grid-cols-3 text-left">
            {[
              { Icon: Target, title: "Leadlijsten op maat", desc: "Wij zoeken exact de bedrijven en contactpersonen die passen bij jouw ideale klant, gefilterd op sector, grootte en regio." },
              { Icon: Mail, title: "Cold outreach", desc: "Gepersonaliseerde cold emails en LinkedIn-berichten die opvallen en reacties genereren." },
              { Icon: TrendingUp, title: "Warme leads aanleveren", desc: "Jij ontvangt alleen contacten die al interesse hebben getoond. Geen koude calls meer, gewoon gesprekken met potentiële klanten." },
            ].map(({ Icon, title, desc }, i) => (
              <div key={title} className="service-card reveal" data-delay={i * 100}>
                <Icon size={36} color="#135aaa" strokeWidth={1.5} />
                <h3 className="font-display mt-6" style={{ fontWeight: 700, fontSize: 26, color: "#061e3e", lineHeight: 1.2 }}>
                  {title}
                </h3>
                <p className="mt-3" style={{ fontWeight: 400, fontSize: 15, color: "#4a5568", lineHeight: 1.75 }}>{desc}</p>
              </div>
            ))}
          </div>

          <div className="mt-16">
            <a href="#contact" className="btn btn-dark">Neem contact op</a>
          </div>
        </div>
      </section>

      {/* HOE HET WERKT */}
      <section id="hoe-het-werkt" className="px-6 py-28 bg-white">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="font-display reveal-title" style={{ fontWeight: 700, fontSize: "clamp(32px, 5vw, 44px)", color: "#061e3e", lineHeight: 1.2 }}>
            Hoe het werkt
          </h2>

          <div className="relative mt-24 grid gap-20 md:gap-12 md:grid-cols-3">
            <div
              className="hidden md:block absolute top-10 left-[16%] right-[16%] step-line"
              style={{ borderTop: "1px dashed #135aaa", zIndex: 0 }}
            />
            {[
              { n: "01", title: "Kennismaking", desc: "We bespreken jouw ideale klant, sector en doelen in een gratis gesprek van 15 minuten." },
              { n: "02", title: "Wij gaan aan de slag", desc: "We bouwen de leadlijst, schrijven de outreach en lanceren de campagne binnen 5 werkdagen." },
              { n: "03", title: "Jij ontvangt leads", desc: "Warme replies landen direct bij jou. Jij voert de gesprekken, wij zorgen voor nieuwe klanten." },
            ].map((s, i) => (
              <div
                key={s.n}
                className="relative reveal-left flex flex-col items-center text-center px-2 pt-8"
                data-delay={i * 150}
                style={{ zIndex: 1 }}
              >
                <span className="step-ghost">{s.n}</span>
                <div
                  className="font-display relative bg-white px-4"
                  style={{ fontWeight: 700, fontSize: 40, color: "#135aaa", lineHeight: 1, zIndex: 2 }}
                >
                  {s.n}
                </div>
                <h3 className="font-display mt-6 relative" style={{ fontWeight: 700, fontSize: 24, color: "#061e3e", zIndex: 2 }}>
                  {s.title}
                </h3>
                <p className="mt-3 max-w-xs relative" style={{ fontSize: 15, color: "#4a5568", lineHeight: 1.75 }}>
                  {s.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PRICING */}
      <section id="prijzen" className="px-6 py-28" style={{ background: "#f4f7fc" }}>
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="font-display reveal-title" style={{ fontWeight: 700, fontSize: "clamp(32px, 5vw, 44px)", color: "#061e3e", lineHeight: 1.2 }}>
            Transparante prijzen
          </h2>
          <p className="reveal mt-4" data-delay="100" style={{ fontSize: 16, color: "#4a5568", lineHeight: 1.75 }}>
            Geen verborgen kosten. Geen lange contracten. Gewoon resultaat.
          </p>

          <div className="mt-16 grid gap-8 md:grid-cols-3">
            {[
              {
                label: "Starter",
                price: "€150",
                suffix: "/maand",
                desc: "Ideaal om te starten en de eerste resultaten te zien.",
                features: ["50 gekwalificeerde leads/maand", "Cold email outreach", "Maandelijks opzegbaar", "Rapportage elke 2 weken"],
                cta: "Gesprek inplannen",
                ctaClass: "btn btn-outline",
                featured: false,
              },
              {
                label: "Groei",
                price: "€300",
                suffix: "/maand",
                desc: "Voor bedrijven die serieus willen opschalen.",
                features: ["100 gekwalificeerde leads/maand", "Cold email + LinkedIn outreach", "Maandelijks opzegbaar", "Wekelijkse rapportage", "Persoonlijke accountmanager"],
                cta: "Gesprek inplannen",
                ctaClass: "btn btn-primary",
                featured: true,
              },
              {
                label: "Scale",
                price: "Op maat",
                suffix: "",
                desc: "Voor grotere organisaties met specifieke noden.",
                features: ["Onbeperkte leads", "Full-service outreach strategie", "Dedicated team", "Dagelijkse rapportage", "Prioriteit support"],
                cta: "Neem contact op",
                ctaClass: "btn btn-outline",
                featured: false,
              },
            ].map((p, i) => (
              <div key={p.label} className={`price-card reveal${p.featured ? " featured" : ""}`} data-delay={i * 100}>
                {p.featured && <span className="price-badge">Meest gekozen</span>}
                <span className="price-label">{p.label}</span>
                <div className="price-amount">
                  {p.price}
                  {p.suffix && <span className="price-suffix">{p.suffix}</span>}
                </div>
                <p className="price-desc">{p.desc}</p>
                <div className="price-divider" />
                <ul className="price-features">
                  {p.features.map((f) => (
                    <li key={f}>
                      <Check size={16} color="#135aaa" strokeWidth={3} style={{ flexShrink: 0, marginTop: 2 }} />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
                <a href="#contact" className={`${p.ctaClass} price-cta`}>{p.cta}</a>
              </div>
            ))}
          </div>

          <p className="reveal mt-10" data-delay="300" style={{ fontFamily: "Inter, system-ui, sans-serif", fontWeight: 400, fontSize: 13, color: "#4a5568" }}>
            Alle pakketten starten met een gratis kennismakingsgesprek van 15 minuten.
          </p>
        </div>
      </section>

      {/* CONTACT */}
      <section id="contact" className="px-6 py-28 text-center" style={{ background: "#061e3e", color: "#fff" }}>
        <div className="max-w-2xl mx-auto">
          <h2 className="font-display reveal-title" style={{ fontWeight: 700, fontSize: "clamp(32px, 5vw, 44px)", color: "#fff", lineHeight: 1.2 }}>
            Klaar om te groeien?
          </h2>
          <p className="reveal mt-5" data-delay="100" style={{ fontSize: 17, color: "#cbd5e1", lineHeight: 1.75 }}>
            Plan een gratis gesprek van 15 minuten en ontdek wat FlowLeads voor jouw bedrijf kan doen.
          </p>
          <div className="reveal mt-10" data-delay="200">
            <BookingForm />
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-white px-6 py-10" style={{ borderTop: "1px solid #e2e8f0" }}>
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-center">
          <Logo height={36} />
          <p style={{ fontSize: 14, color: "#4a5568" }}>
            © 2026 FlowLeads. Alle rechten voorbehouden.
          </p>
        </div>
      </footer>
    </div>
  );
}
